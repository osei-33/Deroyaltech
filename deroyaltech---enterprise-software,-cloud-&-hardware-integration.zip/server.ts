import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const DATA_FILE = path.resolve(DATA_DIR, 'site-data.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial site data template
const getInitialData = () => {
  return {
    config: {
      logoUrl: '/assets/aistudio/Deroyaltech_Digital_Innovation_Logo_9f10ddb1.png',
      currencySymbol: 'GH₵',
      currencyCode: 'GHS',
      accentTheme: 'deroyal-dual',
      overlayStyle: 'ambient-glass',
      heroHeadline: 'Full-stack software, custom CRM, and integrated hardware workflows.',
      heroSubtitle: 'DeRoyalTech engineers web platforms, native mobile applications, bespoke CRM architectures, and multi-cloud infrastructure—seamlessly integrated with industrial sensors, edge gateways, and enterprise computer peripherals to streamline operations.',
      contact: {
        companyName: 'DeRoyalTech Systems Limited',
        tagline: 'Innovate · Build · Grow',
        phonePrimary: '+233 (0) 30 294 8821',
        phoneSecondary: '+233 (0) 24 590 1284',
        emailGeneral: 'info@deroyaltech.com',
        emailSales: 'sales@deroyaltech.com',
        emailSupport: 'support@deroyaltech.com',
        physicalAddress: 'Suite 402, Standard Chartered Building, Airport City & Spintex Tech Corridor',
        cityCountry: 'Accra, Ghana',
        businessHours: 'Mon - Fri: 8:00 AM - 6:00 PM GMT (24/7 DevOps Support Standby)',
        whatsappNumber: '+233245901284'
      },
      social: {
        whatsapp: 'https://wa.me/233245901284',
        facebook: 'https://facebook.com/deroyaltech',
        tiktok: 'https://tiktok.com/@deroyaltech',
        instagram: 'https://instagram.com/deroyaltech',
        linkedin: 'https://linkedin.com/company/deroyaltech'
      },
      enableVideoPreviews: true
    },
    hardware: [],
    projects: [],
    inquiries: [
      {
        id: 'DRT-INQ-9481',
        createdAt: new Date().toISOString(),
        fullName: 'Kwame Mensah',
        email: 'k.mensah@ghanashippers.org',
        company: 'West Africa Shippers Council',
        projectType: 'turnkey',
        budget: 'GH₵ 150,000 - GH₵ 400,000',
        timeline: 'Within 2-3 months',
        scopeNotes: 'Warehouse scanner fleet integration and custom CRM pipeline synchronization',
        message: 'Looking to deploy 45 rugged handheld RFID terminals with real-time cloud data telemetry.',
        status: 'New'
      }
    ]
  };
};

const loadData = () => {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Error reading site data file:', err);
  }
  const init = getInitialData();
  saveData(init);
  return init;
};

const saveData = (data: any) => {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving site data file:', err);
  }
};

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // API Routes
  app.get('/api/site-data', (_req: Request, res: Response) => {
    const data = loadData();
    res.json(data);
  });

  app.post('/api/site-data', (req: Request, res: Response) => {
    const current = loadData();
    const updated = { ...current, ...req.body };
    saveData(updated);
    res.json({ success: true, data: updated });
  });

  // Inquiries endpoints
  app.post('/api/inquiries', (req: Request, res: Response) => {
    const data = loadData();
    const newInquiry = {
      id: `DRT-INQ-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: new Date().toISOString(),
      status: 'New',
      ...req.body
    };
    data.inquiries = [newInquiry, ...(data.inquiries || [])];
    saveData(data);
    res.json({ success: true, inquiry: newInquiry });
  });

  app.patch('/api/inquiries/:id', (req: Request, res: Response) => {
    const data = loadData();
    const id = req.params.id;
    data.inquiries = (data.inquiries || []).map((inq: any) => 
      inq.id === id ? { ...inq, ...req.body } : inq
    );
    saveData(data);
    res.json({ success: true });
  });

  // Live Support Chat endpoints
  app.get('/api/chats', (_req: Request, res: Response) => {
    const data = loadData();
    res.json(data.chatThreads || []);
  });

  app.post('/api/chats/sync', (req: Request, res: Response) => {
    const data = loadData();
    data.chatThreads = req.body.chatThreads || [];
    saveData(data);
    res.json({ success: true });
  });

  // Service Requests endpoints
  app.get('/api/service-requests', (_req: Request, res: Response) => {
    const data = loadData();
    res.json(data.serviceRequests || []);
  });

  app.post('/api/service-requests/sync', (req: Request, res: Response) => {
    const data = loadData();
    data.serviceRequests = req.body.serviceRequests || [];
    saveData(data);
    res.json({ success: true });
  });

  // Tracked Projects endpoints
  app.get('/api/tracked-projects', (_req: Request, res: Response) => {
    const data = loadData();
    res.json(data.trackedProjects || []);
  });

  app.post('/api/tracked-projects/sync', (req: Request, res: Response) => {
    const data = loadData();
    data.trackedProjects = req.body.trackedProjects || [];
    saveData(data);
    res.json({ success: true });
  });

  // Serve Vite app
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {}
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DeRoyalTech Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
